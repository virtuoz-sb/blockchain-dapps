import { Nft } from '../interfaces/Nft';

export const GET_NFTS = 'GET_NFTS';

export interface GetNftsStateType {
    nfts: Nft[];
}

interface GetNftsActionType {
  type: typeof GET_NFTS;
  payload: Nft[];
}

export type NftActionTypes = GetNftsActionType;

import { getNftsAction } from '../actions/NftActions';
import { Dispatch } from 'redux';
import { NftActionTypes } from '../types/NftTypes';
import contracts from "../../contracts"
import jQuery from 'jquery';

export const getNfts = (walletAddress: string) => {
  return function (dispatch: Dispatch<NftActionTypes>) {
      if (window.web3 && window.web3.eth) {
        let SantaV1_Contract: any = new window.web3.eth.Contract(contracts.abis.SantaV1, contracts.address.SantaV1)
    
        const tmpData: any = []
        return SantaV1_Contract.methods.tokensOfOwner(walletAddress).call({
            from: walletAddress
        })
            .then((tokens: any) => {
                const SantaV1_BaseUri = 'https://api.santafeapp.io/asset/';
                for (let i = 0; i < tokens.length; i++) {
                  jQuery.get(SantaV1_BaseUri + tokens[i] + "/")
                  .then((metaData: any) => {
                      metaData = JSON.parse(metaData)
                      metaData.contractAddress = contracts.address.SantaV1
                      tmpData.push(metaData)
                      dispatch(getNftsAction(tmpData));
                  })
                }
                return tmpData
            })
    
    }
  };
  
};

export const updateNfts = (nfts: any) => {
  console.log("updateNfts", nfts)
  return function (dispatch: Dispatch<NftActionTypes>) {
    dispatch(getNftsAction(nfts));
     return nfts
  }
};
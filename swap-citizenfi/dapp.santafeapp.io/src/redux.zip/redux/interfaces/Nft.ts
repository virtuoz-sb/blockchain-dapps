export interface Nft {
    name: string;
    id: number;
    image: string;
    attributes: any;
}
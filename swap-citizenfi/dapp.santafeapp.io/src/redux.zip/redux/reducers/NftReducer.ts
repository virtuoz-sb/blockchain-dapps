import {
    GET_NFTS,
    GetNftsStateType,
    NftActionTypes
  } from '../types/NftTypes';
  
  const initialStateGetNfts: GetNftsStateType = {
    nfts: []
  };
  
  export const getNftsReducer = (
    state = initialStateGetNfts,
    action: NftActionTypes
  ): GetNftsStateType => {
    switch (action.type) {
      case GET_NFTS:
        return {
          ...state,
          nfts: action.payload
        };
      default:
        return state;
    }
  };

import { combineReducers } from 'redux';
import { getNftsReducer } from './NftReducer';

const rootReducer = combineReducers({
  nfts: getNftsReducer
});

export default rootReducer;
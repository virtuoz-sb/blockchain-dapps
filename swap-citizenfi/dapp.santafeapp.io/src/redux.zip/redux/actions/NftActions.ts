import { GET_NFTS, NftActionTypes } from '../types/NftTypes';
import { Nft } from '../interfaces/Nft';

export const getNftsAction = (nfts: Nft[]): NftActionTypes => {
  return {
    type: GET_NFTS,
    payload: nfts
  };
};
